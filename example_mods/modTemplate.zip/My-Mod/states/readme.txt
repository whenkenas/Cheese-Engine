Put your custom state scripts here!

IMPORTANT NOTES:
- Only HSCRIPT (.hx) files are supported
- ALWAYS include "import backend.StateManager;" at the top
- File name must match the state name (e.g., MainMenuState.hx)

=== BASIC STRUCTURE ===

import backend.StateManager;

var mySprite;

function create(state) {
    mySprite = new FlxSprite().loadGraphic(Paths.image('myImage'));
    add(mySprite);  // Short form
    // state.add(mySprite);  // Also works!
}

function update(elapsed) {
    if(FlxG.keys.justPressed.ENTER) {
        StateManager.switchState('FreeplayState');
    }
}

=== INITIAL STATE (Auto-load on game start) ===

To make your state load first when the mod starts, add this function:

function isInitialState() {
    return true;
}

Example - FreeplayState.hx that loads on startup:

import backend.StateManager;

function isInitialState() {
    return true;  // This state loads on game start
}

function create(state) {
    // Your freeplay code here
}

=== PLAYSTATE INTEGRATION ===

When going to PlayState, set where to return after the song ends OR when exiting:

if(FlxG.keys.justPressed.ENTER) {
    PlayState.SONG = Song.loadFromJson(songName, songName.toLowerCase());
    PlayState.isStoryMode = false;
    PlayState.previousState = 'FreeplayState';  // For editors (7/8 keys)
    setReturnState('FreeplayState');  // Where to go when exiting or finishing
    LoadingState.loadAndSwitchState(new PlayState());
}

=== SONG SCRIPTS (Control return state from song data) ===

In your song's script (data/song-name/script.lua or script.hx):

-- Lua Example:
function onEndSong()
    -- Called when song finishes
    setReturnState('MyCustomState')
    return Function_Continue
end

function onExitSong()
    -- Called when exiting from pause menu
    setReturnState('MyCustomState')
    return Function_Continue
end

// HScript Example:
function onEndSong() {
    // Called when song finishes
    setReturnState('MyCustomState');
    return Function_Continue;
}

function onExitSong() {
    // Called when exiting from pause menu
    setReturnState('MyCustomState');
    return Function_Continue;
}

Note: Both callbacks work the same way - use whichever fits your needs!
You can set different states for finishing vs exiting if desired.

=== EDITOR SUPPORT ===

Editors automatically return to your custom state when you exit them!

Opening editors from your state:

function update(elapsed) {
    if(FlxG.keys.justPressed.SEVEN) {
        FlxG.mouse.visible = false;
        state.persistentUpdate = false;
        state.openSubState(new states.editors.EditorPickerSubstate());
    }
}

function onCloseSubState() {
    state.persistentUpdate = true;
}

=== TIPS ===

=== AVAILABLE SHORTCUTS ===

You can use these functions directly without "state." prefix:

add(object)                 // Add object to state (same as state.add)
remove(object)              // Remove object (same as state.remove)
insert(position, object)    // Insert at position (same as state.insert)
openSubState(substate)      // Open a substate
closeSubState()             // Close current substate
switchState(nextState)      // Switch to another state
resetState()                // Reset current state

Direct access to:
members                     // State members array
camera                      // Main camera (FlxG.camera)
cameras                     // Camera system (FlxG.cameras)
save                        // Save system (FlxG.save)
sound                       // Sound system (FlxG.sound)

Both forms work:
add(mySprite);              // Short form
state.add(mySprite);        // Original form (still works!)

- Use StateManager.switchState('StateName') for navigation
- Set antialiasing: ClientPrefs.data.antialiasing
- Play sounds: FlxG.sound.play(Paths.sound('soundName'))
- Create new states with any name (SigmaState.hx, CreditsState.hx, etc.)
- Check original engine states for reference examples
- setReturnState() works for both finishing songs and exiting via pause menu