Put your custom state scripts here!

IMPORTANT NOTES:
- Only HSCRIPT (.hx) files are supported
- ALWAYS include "import backend.StateManager;" at the top of your script
- File name must match the state name (e.g., MainMenuState.hx for Main Menu)

HOW TO USE:
1. Create a new .hx file with your state name (e.g., "MainMenuState.hx")
2. Start with: import backend.StateManager;
3. Add your create() function to initialize sprites and objects
4. Add your update(elapsed) function for logic and controls
5. Use StateManager.switchState('StateName') to navigate between states

EXAMPLE STRUCTURE:

import backend.StateManager;

var mySprite;

function create(state) {
    mySprite = new FlxSprite().loadGraphic(Paths.image('myImage'));
    state.add(mySprite);
}

function update(elapsed) {
    if(FlxG.keys.justPressed.ENTER) {
        StateManager.switchState('FreeplayState');
    }
}

SWITCHING STATES:
- Use StateManager.switchState('StateName') instead of MusicBeatState.switchState()
- This ensures custom HScript states load correctly
- Available states: TitleState, MainMenuState, StoryMenuState, FreeplayState, OptionsState, etc.

CUSTOM STATES:
You can create completely new states that don't replace existing ones!

Examples:
- TitleState.hx (replaces the original Title State)
- SigmaState.hx (creates a brand new state called "SigmaState")
- CreditsState.hx (replaces the original Credits State)
- MyCustomState.hx (creates "MyCustomState")

Access custom states with: StateManager.switchState('YourStateName');

TIPS (Optional - Not required):
- Check original states for reference
- Use state.add() to add sprites to the state
- Always set antialiasing with ClientPrefs.data.antialiasing
- Use FlxG.sound.play(Paths.sound('soundName')) for sound effects